# SpaceWars
Game for TTGO T-Watch 

Here is my game that i created for LilyGO TTGO T-Display developement board, But it can be played
on any ESP32 based board and tft display. Used library for TFT Display is https://github.com/Bodmer/TFT_eSPI

Here is video about this game 
https://youtu.be/KZMkGDyGjxQ

![GitHub Logo](/tuumb.JPG)
Format: ![Alt Text](url)
